import java.util.*;

public class RisingTides {

    public static boolean[][] floodedRegionsIn(double[][] terrain, GridLocation[] sources, double height) {


        int hit = terrain.length;
        int width = terrain[0].length;
        boolean[][] arr = new boolean[terrain.length][terrain[0].length];

        ArrayList<GridLocation> queue = new ArrayList<GridLocation>();

        for(GridLocation thing: sources){
            if (terrain[thing.row][thing.col] <= hit){
                arr[thing.row][thing.col] = true;
                queue.add(thing);
            }
        }

        while(!queue.isEmpty()){
            GridLocation curr = queue.get(0);
            queue.remove(0);

            if(curr.row+1<hit&&terrain[curr.row+1][curr.col]<=height && !arr[curr.row+1][curr.col]){
                arr[curr.row+1][curr.col] = true;
                queue.add(new GridLocation(curr.row+1, curr.col));
            }

            if(curr.row-1>-1&&terrain[curr.row-1][curr.col]<=height && !arr[curr.row-1][curr.col]){
                arr[curr.row-1][curr.col] = true;
                queue.add(new GridLocation(curr.row-1, curr.col));
            }

            if(curr.col+1<width&&terrain[curr.row][curr.col+1]<=height && !arr[curr.row][curr.col+1]){
                arr[curr.row][curr.col+1] = true;
                queue.add(new GridLocation(curr.row, curr.col+1));
            }

            if(curr.col-1>-1&&terrain[curr.row][curr.col-1]<=height&& !arr[curr.row][curr.col-1]){
                arr[curr.row][curr.col-1] = true;
                queue.add(new GridLocation(curr.row, curr.col-1));
            }

            // Bottom-right
            if (curr.row + 1 < hit && curr.col + 1 < width && terrain[curr.row + 1][curr.col + 1] <= height && !arr[curr.row + 1][curr.col + 1]) {
                arr[curr.row + 1][curr.col + 1] = true;
                queue.add(new GridLocation(curr.row + 1, curr.col + 1));
            }

            // Bottom-left
            if (curr.row + 1 < hit && curr.col - 1 >= 0 && terrain[curr.row + 1][curr.col - 1] <= height && !arr[curr.row + 1][curr.col - 1]) {
                arr[curr.row + 1][curr.col - 1] = true;
                queue.add(new GridLocation(curr.row + 1, curr.col - 1));
            }

            // Top-right
            if (curr.row - 1 >= 0 && curr.col + 1 < width && terrain[curr.row - 1][curr.col + 1] <= height && !arr[curr.row - 1][curr.col + 1]) {
                arr[curr.row - 1][curr.col + 1] = true;
                queue.add(new GridLocation(curr.row - 1, curr.col + 1));
            }

            // Top-left
            if (curr.row - 1 >= 0 && curr.col - 1 >= 0 && terrain[curr.row - 1][curr.col - 1] <= height && !arr[curr.row - 1][curr.col - 1]) {
                arr[curr.row - 1][curr.col - 1] = true;
                queue.add(new GridLocation(curr.row - 1, curr.col - 1));
            }


        }

        return arr;
   
    }
}
